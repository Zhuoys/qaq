package com.atguigu.daijia.customer.mapper;

import com.atguigu.daijia.model.entity.customer.CustomerInfo;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface CustomerInfoMapper extends BaseMapper<CustomerInfo> {

}
