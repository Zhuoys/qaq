"use strict";
const TOKEN_KEY = "token";
const USER_KEY = "user";
exports.TOKEN_KEY = TOKEN_KEY;
exports.USER_KEY = USER_KEY;
